# JAS Stripe Backend (Flask)

This backend supports:
- Stripe Checkout Sessions
- Invoice creation
- Customer listing
- Payment tracking

## Deploy on Railway
1. Upload this repo to GitHub
2. Connect GitHub to Railway
3. Set environment variable:
   `STRIPE_API_KEY = sk_live_your_key_here`
