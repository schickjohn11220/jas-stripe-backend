from flask import Flask, request, jsonify
import stripe
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)

stripe.api_key = os.getenv('STRIPE_API_KEY', 'sk_test_your_fallback_key')

@app.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    data = request.json
    try:
        session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': data['currency'],
                    'product_data': {
                        'name': data['name'],
                    },
                    'unit_amount': data['amount'],
                },
                'quantity': 1,
            }],
            mode='payment',
            success_url='https://jas-lowss-site.netlify.app?success=true',
            cancel_url='https://jas-lowss-site.netlify.app?canceled=true',
        )
        return jsonify({'id': session.id})
    except Exception as e:
        return jsonify(error=str(e)), 500

@app.route('/create-invoice', methods=['POST'])
def create_invoice():
    data = request.json
    try:
        customer = stripe.Customer.create(
            email=data['email'],
            name=data.get('name', '')
        )
        stripe.InvoiceItem.create(
            customer=customer.id,
            amount=data['amount'],
            currency=data['currency'],
            description=data['description']
        )
        invoice = stripe.Invoice.create(
            customer=customer.id,
            auto_advance=True
        )
        return jsonify({'invoice_url': invoice.hosted_invoice_url})
    except Exception as e:
        return jsonify(error=str(e)), 500

@app.route('/customers', methods=['GET'])
def list_customers():
    try:
        customers = stripe.Customer.list(limit=10)
        return jsonify(customers)
    except Exception as e:
        return jsonify(error=str(e)), 500

@app.route('/payments', methods=['GET'])
def list_payments():
    try:
        payments = stripe.PaymentIntent.list(limit=10)
        return jsonify(payments)
    except Exception as e:
        return jsonify(error=str(e)), 500

if __name__ == '__main__':
    app.run(port=4242)
